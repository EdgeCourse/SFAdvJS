var output = document.getElementById("output");
var btn = document.getElementById("btn");
btn.addEventListener("click", loadDoc);
function loadDoc() {
	var xhttp = new XMLHttpRequest();
	xhttp.open("GET", "data.json", true);
	xhttp.send();
	xhttp.addEventListener("readystatechange", function() {
		if (xhttp.readyState == 4 && xhttp.status == 200) {
			var jsonobj = JSON.parse(xhttp.responseText);
			var len = jsonobj.length;
			for(i = 0; i < len; i++){
				output.innerHTML += "Hello, I am " + jsonobj[i].fName + " studying " + jsonobj[i].topic + "!<br>";
			}
		}
	});
}