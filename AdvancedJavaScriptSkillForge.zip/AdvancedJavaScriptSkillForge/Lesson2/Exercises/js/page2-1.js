var output = document.getElementById("output");
var btn = document.getElementById("btn");
btn.addEventListener("click", loadDoc);
function loadDoc() {
	//put AJAX code in here



}