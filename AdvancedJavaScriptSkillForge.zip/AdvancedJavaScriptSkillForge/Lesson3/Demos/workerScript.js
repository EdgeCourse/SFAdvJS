var i = 100;
function countDown() {
i--;
  	postMessage(i);
//runs countDown function recursively
  	setTimeout("countDown()",500);
}
countDown();
