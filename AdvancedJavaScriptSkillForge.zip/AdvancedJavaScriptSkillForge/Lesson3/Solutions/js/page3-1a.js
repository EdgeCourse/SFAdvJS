localStorage.setItem("fName", "Bob");
localStorage.setItem("topic1", "JavaScript");
localStorage.setItem("topic2", "jQuery");
localStorage.setItem("topic3", "Node.js");

