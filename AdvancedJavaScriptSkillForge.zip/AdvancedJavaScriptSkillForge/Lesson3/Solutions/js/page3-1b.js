var uName = localStorage.getItem("fName");
var t1 = localStorage.getItem("topic1");
var t2 = localStorage.getItem("topic2");
var t3 = localStorage.getItem("topic3");

console.log("Hello, my name is " + uName + 
	" and I would like to learn " + t1 + ", " + t2 + 
	", and " + t3 + "."
	)