$(document).ready(function(){
	$("p").click(function(){
		$(this).css("background-color", "yellow");
	})
});