var app = angular.module('myApp', []);
app.controller('myCtrl', function($scope) {
	$scope.num1= 10;
	$scope.num2= 20;
});