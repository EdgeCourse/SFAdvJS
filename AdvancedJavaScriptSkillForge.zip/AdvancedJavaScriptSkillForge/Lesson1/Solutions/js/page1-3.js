var Person = {
  				init: function ( fName, topic ) {
    					this.fName = fName;
    					this.topic = topic;
  				},
  				getInfo: function () {
console.log( "Hello, my name is " + this.fName + 
	" and I am studying " + this.topic + ".");
  				}
};
function createStudent( uname, subject ) {
  				function S() {};
  					S.prototype = Person;
  					var s = new S();
  					s.init( uname, subject );
  					return s;
}
var student1 = createStudent( "Bob", "JavaScript" );
student1.getInfo();

var student2 = createStudent( "Mary", "jQuery" );
student2.getInfo();