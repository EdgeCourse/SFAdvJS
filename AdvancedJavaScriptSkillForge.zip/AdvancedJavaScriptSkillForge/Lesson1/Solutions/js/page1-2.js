var myNamespace = (function () {
  		return {
    		//public variable
    		//this public function uses private variables
    		publicGreet: function( fName ) {
    		console.log("Hello, I am " + fName);
      	},
      		publicStudy: function(topic) {
    		console.log("I am studying " + topic + ".");
      	}

    };
})();

//"hello"
myNamespace.publicGreet("Bob");
myNamespace.publicStudy("JavaScript");

