//wrap function expression in parentheses
(function() {
	var greet = "Hello World";
	console.log(greet);
})();//these parentheses call the IIFE


