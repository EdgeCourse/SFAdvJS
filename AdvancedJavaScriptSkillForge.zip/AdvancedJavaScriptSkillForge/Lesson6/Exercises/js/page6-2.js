window.addEventListener("load", function(){
    frm = document.getElementById("frmCheck");
    frm.addEventListener("submit", checkAge);  
})
function checkAge() {
    var message //, age;
    message = document.getElementById("message");
    ageVal = document.getElementById("txtAge").value;
  
    //add try and throw

    //this catches the error
    catch(error) {
        message.innerHTML = "Age is " + error;
      event.preventDefault();
    }
//    finally{
//      alert("good job filling out the form")

//    }
}
