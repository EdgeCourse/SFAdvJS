var x, topics, arr;
arr = ["Jim", "Robert", "Martha", "Sarah"];
[x, ...topics] = arr;
console.log(topics[2]);
[, b, c] = arr;
console.log(b, c);