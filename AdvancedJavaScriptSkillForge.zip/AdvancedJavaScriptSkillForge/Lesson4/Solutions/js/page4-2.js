{    
	let fName = "Bob";    
	console.log( fName ); // Bob
}
//console.log( fName ); // undefined

