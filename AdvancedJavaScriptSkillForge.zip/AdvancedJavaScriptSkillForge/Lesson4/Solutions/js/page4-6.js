function greet(f, l, subject = "JavaScript"){
	return `I am ${f} ${l}, studying ${subject}!`;	
}
//returns "Hello, I am Bob Smith, studying JavaScript"
console.log(greet("Bob", "Smith"));

//returns "Hello, I am Martha Jones, studying jQuery"
console.log(greet("Martha", "Jones", "jQuery"));
