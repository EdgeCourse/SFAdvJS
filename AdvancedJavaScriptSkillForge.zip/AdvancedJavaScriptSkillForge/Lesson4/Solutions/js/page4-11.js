var map = new Map();
var key1 = "first name",
    key2 = "last name"

map.set(key1, "Martha");
map.set(key2, "Smith");
console.log(map.get(key1), map.get(key2));

for(let [key, value] of map.entries()){
				console.log(key, value);
}

