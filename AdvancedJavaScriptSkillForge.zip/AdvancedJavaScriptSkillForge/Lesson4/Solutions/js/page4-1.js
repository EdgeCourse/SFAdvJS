for (let i = 1; i <= 10; i++) {
	console.log(i); //i is each iteration	
}
console.log("outside loop, i is " + i);
