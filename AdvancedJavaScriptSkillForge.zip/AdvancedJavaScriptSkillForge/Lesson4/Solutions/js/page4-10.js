class Shape{
	constructor(width, height){
		this.w = width;
		this.h = height;
	}
	set width(width){
		this.w = width;
	} 
	get width () { 
		return this.w;                
	}
	set height (height) { 
		this.h = height;             
	}
	get height () { 
		return this.h;               
	}
	get area () { 
		return this.w * this.h; 
	}
}
class Square extends Shape {
static size () {
      return new Square(20, 20)
    			}
  			get area() {
    				return this.height * this.width;
  			}
  			set area(value) {
    				this.area = value;
  			} 
}
//do not use "new" here
var square1 = Square.size();
console.log(square1.area);//400
var square2 = new Square(10,10);
console.log(square2.area);//100


