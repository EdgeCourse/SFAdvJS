var students = ["Jim", "Mary", "Barbara", "John"];
for(let value of students){
	console.log(value);
}

