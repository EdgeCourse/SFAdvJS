var fName = "Martha";
var lName = "Smith";
console.log(`Hello ${fName} ${lName}!`);//Hello Martha Smith      

