var email = "me@aol.com"; 
console.log(email.startsWith("a"));//false
console.log(email.endsWith(".com"));//true
console.log(email.includes("@"));// true

