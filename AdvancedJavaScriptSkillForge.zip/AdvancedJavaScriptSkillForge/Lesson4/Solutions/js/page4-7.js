var subjects = ["Backbone", "Angular", "Node", "Ember"];
var allSubjects = ["JavaScript", "jQuery", ...subjects];
console.log(allSubjects);
console.log(allSubjects[3]);
console.log("When not using the spread operator:")
var allSubjects2 = ["JavaScript", "jQuery", subjects];
console.log(allSubjects2);

