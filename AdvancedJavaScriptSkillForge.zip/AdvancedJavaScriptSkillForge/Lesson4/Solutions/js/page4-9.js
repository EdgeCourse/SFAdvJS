class Shape{
	constructor(width, height){
		this.w = width;
		this.h = height;
	}
	set width(width){
		this.w = width;
	} 
	get width () { 
		return this.w;                
	}
	set height (height) { 
		this.h = height;             
	}
	get height () { 
		return this.h;               
	}
	get area () { 
		return this.w * this.h; 
	}
}
var rect = new Shape(20, 10);
console.log(rect.area);//200
console.log(rect.width);//20
console.log(rect.height);//10
